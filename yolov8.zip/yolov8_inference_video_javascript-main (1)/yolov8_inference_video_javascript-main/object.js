const video = document.querySelector("video");
// //const worker = new Worker("./yolov8_inference_video_javascript-main/worker.js");

let boxes = [];
let interval
let busy = false;
let streaming = false;
let width, height;
let src, dst, cap;
let fun_fiter ,type_num;
let deutranopia_degree , protanopia_degree;
let model_promiss;

// async function run_model(input) {
//     const model = await tf.loadLayersModel("./weights/model.json");
//     return model;
// }
