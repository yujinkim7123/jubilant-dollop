const video = document.querySelector("video");
// tf.setBackend('webgl');

const worker = new Worker("./yolov8_inference_video_javascript-main/worker.js");
//const tf = require('@tensorflow/tfjs-node');

let boxes = [];
let interval
let busy = false;
let streaming = false;
let width, height;
let src, dst, cap;
let fun_fiter ,type_num;
let deutranopia_degree , protanopia_degree;
let model_promiss;

// const pascalvoc = [[ 0,0,0 ],[ 128,0,0 ],[ 0,128,0 ],
//                     [ 128,128,0 ],[ 0,0,128 ],[ 128,0,128 ],
//                     [ 0,128,128 ],[ 128,128,128 ],[ 64,0,0 ],
//                     [ 192,0,0 ],[ 64,128,0 ],[ 192,128,0 ],
//                     [ 64,0,128 ],[ 192,0,128 ],[ 64,128,128 ],
//                     [ 192,128,128 ],[ 0,64,0 ],[ 128,64,0 ],
//                     [ 0,192,0 ],[ 128,192,0 ],[ 0,64,128 ],
//                     [ 128,64,128 ],[ 0,192,128 ],[ 128,192,128 ],
//                     [ 64,64,0 ],[ 192,64,0 ],[ 64,192,0 ],
//                     [ 192,192,0 ],[ 64,64,128 ],[ 192,64,128 ],
//                     [ 64,192,128 ],[ 192,192,128 ],[ 0,0,64 ],
//                     [ 128,0,64 ],[ 0,128,64 ],[ 128,128,64 ],
//                     [ 0,0,192 ],[ 128,0,192 ],[ 0,128,192 ],
//                     [ 128,128,192 ],[ 64,0,64 ]];



// function run_model(input) {
//     const model = tf.loadLayersModel("./yolov8_inference_video_javascript-main/weights/model.json");
//     return model;
// }

function successCallback(stream) {
    // video.width = 640; video.height = 640;
     video.srcObject = stream;
     video.play();
   }
   
   function errorCallback(error) {
     console.log(error);
   }

   
function setSize() {

    width = 640; height = 640;

    deutranopia_degree = 0;
    protanopia_degree = 0;

}

const constraints = {
    video: { facingMode: "user", }, audio: false
  };

video.addEventListener("play", () => {

    setSize();
    chageLangSelect();
    const video = document.getElementById("video");
    const canvas1 = document.getElementById("canva1");
    const canvas2 = document.getElementById("canva2");
    canvas1.width = width; canvas1.height = height;
    canvas2.width = width; canvas2.height = height;
    const context1 = canvas1.getContext("2d");
    const context2 = canvas2.getContext("2d");


    if (streaming === false) {
        navigator.getUserMedia(constraints, successCallback, errorCallback);
        streaming = !streaming;
    }

      // This function will run once the video has finished loading its data
      // console.log('Video data has loaded.');

      // run_model().then((model_promiss) => { interval = setInterval(() => {

        // video.addEventListener('loadeddata', () => {
    interval = setInterval(() => {
        context1.drawImage(video,0,0);
        context2.drawImage(video,0,0);
        const input = prepare_input(canvas1);
        draw_boxes(canvas1, canvas2, boxes);
        // context_img = context1.getImageData(0,0,width,height);
        // detectFrame(context_img, model_promiss, canvas1)
        if (!busy) {            
            worker.postMessage(input); //데이터 다른 별도 프로세스로 전송
            busy = true;
        }
      },60)
  })
  
  // });
// });



//const modelPromise = loadModel();

// function delay(ms = 1000) {
//   return new Promise((resolve) => setTimeout(resolve, ms));
// }

// async function detectFrame(video, model, canvasRef) {
//     tf.engine().startScope();
//     const predictions = model.predict(processInput(video));
//     console.log(predictions)

//     await delay(1000000);
   
//     renderPredictions(predictions, canvasRef);
//     requestAnimationFrame(() => {
//       detectFrame(video, model, canvasRef);
//     });
//     tf.engine().endScope();
//   }

//   function processInput(videoFrame) {
//     const img = tf.browser.fromPixels(videoFrame).toFloat();
//     const scale = tf.scalar(255.);
//     const mean = tf.tensor3d([0.485, 0.456, 0.406], [1, 1, 3]);
//     const std = tf.tensor3d([0.229, 0.224, 0.225], [1, 1, 3]);
//     const normalized = img.div(scale).sub(mean).div(std);
//     const batched = normalized.transpose([2, 0, 1]).expandDims();
//     return batched;
//   }

//   async function renderPredictions(predictions, canvasRef) {
//   const img_shape = [480, 480]
//   const offset = 0;
//   const segmPred = tf.image.resizeBilinear(predictions.transpose([0,2,3,1]),img_shape);
//   const segmMask = segmPred.argMax(3).reshape(img_shape);
//   const width = segmMask.shape.slice(0, 1);
//   const height = segmMask.shape.slice(1, 2);
//   const data = await segmMask.data();
//   const bytes = new Uint8ClampedArray(width * height * 4);
//   //console.log(data)
//     for (let i = 0; i < height * width; ++i) {
//       const partId = data[i];
//       const j = i * 4;
//       if (partId === -1) {
//         bytes[j + 0] = 255;
//         bytes[j + 1] = 255;
//         bytes[j + 2] = 255;
//         bytes[j + 3] = 255;
//       } else {
//         const color = pascalvoc[partId + offset];
//         if (!color) {
//           throw new Error(`No color could be found for part id ${partId}`);
//         }
//         bytes[j + 0] = color[0];
//         bytes[j + 1] = color[1];
//         bytes[j + 2] = color[2];
//         bytes[j + 3] = 255; // Alpha channel
//       }
//     }
//     const out = new ImageData(bytes, width, height);
//     const ctx = canvasRef.getContext("2d");
//     ctx.scale(1.5, 1.5);
//     ctx.putImageData(out, 520, 60);
//   }

worker.onmessage = (event) => {
    const output = event.data;
    const canvas1 = document.getElementById("canva1");
    boxes =  process_output(output, canvas1.width, canvas1.height);
    busy = false;
};

video.addEventListener("pause", () => {
    if (streaming === true){
    const stream = video.srcObject;
    const tracks = stream.getTracks();
    tracks.forEach(track => {
        track.stop();
    });
    clearInterval(interval); //영상 중지하기(해당 함수 중지)
    streaming = !streaming;
    }
});


const playBtn = document.getElementById("play");
const pauseBtn = document.getElementById("pause");
playBtn.addEventListener("click", () => {
    video.play();
});
pauseBtn.addEventListener("click", () => {
    video.pause();
});


// //변환과정

function prepare_input(img) {
    const canvas1 = document.createElement("canvas");
    canvas1.width = width;
    canvas1.height = height;
    const context = canvas1.getContext("2d");
    context.drawImage(img, 0, 0, width, height);
    const data = context.getImageData(0,0,width,height).data;
    const red = [], green = [], blue = [];
    for (let index=0;index<data.length;index+=4) {
        red.push(data[index]/255);
        green.push(data[index+1]/255);
        blue.push(data[index+2]/255);
    }
    return [...red, ...green, ...blue];
}

function process_output(output, img_width, img_height) {
    let boxes = [];
    for (let index=0;index<8400;index++) {
        const [class_id,prob] = [...Array(yolo_classes.length).keys()]
            .map(col => [col, output[8400*(col+4)+index]])
            .reduce((accum, item) => item[1]>accum[1] ? item : accum,[0,0]);
        if (prob < 0.5) {
            continue;
        }

        const label = yolo_classes[class_id];
        const xc = output[index];
        const yc = output[8400+index];
        const w = output[2*8400+index];
        const h = output[3*8400+index];
        const x1 = (xc-w/2)/640*img_width;
        const y1 = (yc-h/2)/640*img_height;
        const x2 = (xc+w/2)/640*img_width;
        const y2 = (yc+h/2)/640*img_height;
        boxes.push([x1,y1,x2,y2,label,prob]);
    }
    boxes = boxes.sort((box1,box2) => box2[5]-box1[5])
    const result = [];
    while (boxes.length>0) {
        result.push(boxes[0]);
        boxes = boxes.filter(box => iou(boxes[0],box)<0.7 || boxes[0][4] !== box[4]);
    }
    return result;
}

function iou(box1,box2) {
    return intersection(box1,box2)/union(box1,box2);
}

function union(box1,box2) {
    const [box1_x1,box1_y1,box1_x2,box1_y2] = box1;
    const [box2_x1,box2_y1,box2_x2,box2_y2] = box2;
    const box1_area = (box1_x2-box1_x1)*(box1_y2-box1_y1)
    const box2_area = (box2_x2-box2_x1)*(box2_y2-box2_y1)
    return box1_area + box2_area - intersection(box1,box2)
}

function intersection(box1,box2) {
    const [box1_x1,box1_y1,box1_x2,box1_y2] = box1;
    const [box2_x1,box2_y1,box2_x2,box2_y2] = box2;
    const x1 = Math.max(box1_x1,box2_x1);
    const y1 = Math.max(box1_y1,box2_y1);
    const x2 = Math.min(box1_x2,box2_x2);
    const y2 = Math.min(box1_y2,box2_y2);
    return (x2-x1)*(y2-y1)
}

Array.matrix = function (m, n, initial) {
    var a, i, j, mat = [];
    for (i = 0; i < m; i += 1) {
        a = [];
        for (j = 0; j < n; j += 1) {
            a[j] = initial;
        }
        mat[i] = a;
    }
    return mat;
};

function matrixVectorMultiply(A, B) {
    // A: 2차원 배열 (m x n)
    // B: 1차원 배열 (n)

    // A의 행과 열 크기
    var rowsA = A.length;
    var colsA = A[0].length;

    // B의 길이 (n)
    var lenB = B.length;

    // B를 열 벡터로 가정하고, 열 벡터와 A의 내적 계산
    if (colsA !== lenB) {
        console.error("행렬 A의 열 수와 벡터 B의 길이가 일치하지 않아 내적이 불가능합니다.");
        return;
    }

    // 결과 벡터 C 생성 (m)
    var C = new Array(rowsA).fill(0);

    // 행렬 내적 계산
    for (var i = 0; i < rowsA; i++) {
        for (var j = 0; j < colsA; j++) {
            C[i] += A[i][j] * B[j];
        }
    }

    return C;
}

function transposeMatrix(matrix) {
    // 입력 행렬의 행과 열 크기
    var rows = matrix.length;
    var cols = matrix[0].length;

    // 전치 행렬 생성 (cols x rows)
    var transpose = new Array(cols);
    for (var i = 0; i < cols; i++) {
        transpose[i] = new Array(rows);
    }

    // 전치 행렬 구성
    for (var i = 0; i < rows; i++) {
        for (var j = 0; j < cols; j++) {
            transpose[j][i] = matrix[i][j];
        }
    }

    return transpose;
}

function correct_fiter(rgb)
{
let fiter;

  mp = [[1 - deutranopia_degree/2, deutranopia_degree/2, 0],
        [protanopia_degree/2, 1 - protanopia_degree/2, 0],
        [protanopia_degree/4, deutranopia_degree/4, 1 - (protanopia_degree + deutranopia_degree)/4]];
  result =  transposeMatrix(mp)
    
    fiter = matrixVectorMultiply(result, rgb);

return fiter;
}

function draw_boxes(canvas1, canvas2, boxes) {
    const ctx1 = canvas1.getContext("2d");
    const ctx2 = canvas2.getContext("2d");
    ctx1.strokeStyle = "#00FF00";
    ctx1.lineWidth = 3;
    ctx1.font = "18px serif";
    ctx2.strokeStyle = "#00FF00";
    ctx2.lineWidth = 3;
    ctx2.font = "18px serif";
    var check_box = [];
    for (i = 0; i < 168400; i += 1) {
        check_box[i] = false;
    }

    boxes.forEach(([x1,y1,x2,y2,label]) => {
        //console.log(x1,y1)
        i_x1 = Math.ceil(x1)
        i_x2 = Math.ceil(x2)
        i_y1 = Math.ceil(y1)
        i_y2 = Math.ceil(y2)

        id1 = ctx1.getImageData(0,0,width, height)
        id2 = ctx2.getImageData(0,0,width, height)

        for(j = i_x1; j < i_x2; j++){
            for(i = i_y1; i <i_y2; i++)
            {

            if(check_box[index] == true)continue;
                check_box[index] = true;

            var index = (i*4) + (j*4*height)     
            var rgb1 = [id1.data[index], id1.data[index + 1], id1.data[index + 2]];
            

            filteredRGB = correct_fiter(rgb1);
            //console.log(filteredRGB)
            id1.data[index] = filteredRGB[0];
            id1.data[index + 1] = filteredRGB[1];
            id1.data[index + 2] = filteredRGB[2];
            

            var rgb2 = [id2.data[index], id2.data[index + 1], id2.data[index + 2]];

            filteredRGB = fun_fiter(rgb2);
            //console.log(filteredRGB)
            id2.data[index] = filteredRGB[0];
            id2.data[index + 1] = filteredRGB[1];
            id2.data[index + 2] = filteredRGB[2];

            }
        }
        ctx1.putImageData(id1, 0, 0);
        //a: 투명도 rgba 로 변환되므로 rgba 값을 
        ctx1.strokeRect(x1,y1,x2-x1,y2-y1);
        ctx1.fillStyle = "#00ff00";
        const width_t = ctx1.measureText(label).width;
        ctx1.fillRect(x1,y1,width_t+10,25);
        ctx1.fillStyle = "#000000";
        ctx1.fillText(label, x1, y1+18);

        ctx2.putImageData(id2, 0, 0);
        //a: 투명도 rgba 로 변환되므로 rgba 값을 
        ctx2.strokeRect(x1,y1,x2-x1,y2-y1);
        ctx2.fillStyle = "#00ff00";
        ctx2.fillRect(x1,y1,width_t+10,25);
        ctx2.fillStyle = "#000000";
        ctx2.fillText(label, x1, y1+18);
    });
}

const yolo_classes = [
    'person', 'bicycle', 'car', 'motorcycle', 'airplane', 'bus', 'train', 'truck', 'boat',
    'traffic light', 'fire hydrant', 'stop sign', 'parking meter', 'bench', 'bird', 'cat', 'dog', 'horse',
    'sheep', 'cow', 'elephant', 'bear', 'zebra', 'giraffe', 'backpack', 'umbrella', 'handbag', 'tie', 'suitcase',
    'frisbee', 'skis', 'snowboard', 'sports ball', 'kite', 'baseball bat', 'baseball glove', 'skateboard',
    'surfboard', 'tennis racket', 'bottle', 'wine glass', 'cup', 'fork', 'knife', 'spoon', 'bowl', 'banana', 'apple',
    'sandwich', 'orange', 'broccoli', 'carrot', 'hot dog', 'pizza', 'donut', 'cake', 'chair', 'couch', 'potted plant',
    'bed', 'dining table', 'toilet', 'tv', 'laptop', 'mouse', 'remote', 'keyboard', 'cell phone', 'microwave', 'oven',
    'toaster', 'sink', 'refrigerator', 'book', 'clock', 'vase', 'scissors', 'teddy bear', 'hair drier', 'toothbrush'
];
