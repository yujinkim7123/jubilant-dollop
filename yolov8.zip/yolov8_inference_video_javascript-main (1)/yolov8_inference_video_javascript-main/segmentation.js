import * as tf from '@tensorflow/tfjs';
tf.setBackend('webgl');

async function load_model() {
    const model = await tf.loadLayersModel("http://127.0.0.1:8080/model.json");
    return model;
  }
  

  detectFrame = (video, model) => {
    tf.engine().startScope();
    const predictions = model.predict(this.process_input(video));
    this.renderPredictions(predictions);
    requestAnimationFrame(() => {
      this.detectFrame(video, model);
    });
    tf.engine().endScope();
};

  
const modelPromise = load_model();

process_input(video_frame){
    const img = tf.browser.fromPixels(video_frame).toFloat();
    const scale = tf.scalar(255.);
    const mean = tf.tensor3d([0.485, 0.456, 0.406], [1,1,3]);
    const std = tf.tensor3d([0.229, 0.224, 0.225], [1,1,3]);
    const normalised = img.div(scale).sub(mean).div(std);
    const batched = normalised.transpose([2,0,1]).expandDims();
    return batched;
  };


