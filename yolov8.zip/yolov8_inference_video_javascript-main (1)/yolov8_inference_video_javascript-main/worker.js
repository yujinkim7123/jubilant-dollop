importScripts("https://cdn.jsdelivr.net/npm/onnxruntime-web/dist/ort.min.js");
// const tf = require('@tensorflow/tfjs');
// const pascalvoc = [
//     [0, 0, 0], [128, 0, 0], [0, 128, 0], [128, 128, 0],
//     [0, 0, 128], [128, 0, 128], [0, 128, 128], [128, 128, 128],
//     [64, 0, 0], [192, 0, 0], [64, 128, 0], [192, 128, 0],
//     [64, 0, 128], [192, 0, 128], [64, 128, 128], [192, 128, 128],
//     [0, 64, 0], [128, 64, 0], [0, 192, 0], [128, 192, 0],
//     [0, 64, 128], [128, 64, 128], [0, 192, 128], [128, 192, 128],
//     [64, 64, 0], [192, 64, 0], [64, 192, 0], [192, 192, 0],
//     [64, 64, 128]
//   ];


let model = null;

onmessage = async(event) => {
    const input = event.data;
    const output = await run_model(input);
    postMessage(output);
}

async function run_model(input) {
    if (!model) {
        model = await ort.InferenceSession.create("./yolov8n.onnx");
        
    }
    input = new ort.Tensor(Float32Array.from(input),[1, 3, 640, 640]);
    const outputs = await model.run({images:input});
    return outputs["output0"].data;
}
