import numpy as np

mp = np.array([[1 - deutranopia_degree/2, deutranopia_degree/2, 0],
        [protanopia_degree/2, 1 - protanopia_degree/2, 0],
        [protanopia_degree/4, deutranopia_degree/4, 1 - (protanopia_degree + deutranopia_degree)/4]]).T

   
fiter = (np.dot(rgb, mp)*255)

return fiter;