
function changemenu(selectValue){
    console.log(selectValue)
    if (selectValue === 'hcirn') {
        document.getElementById("hd1").style.display = "block"
        document.getElementById("hd2").style.display = "block"
        document.getElementById("hd3").style.display = "block"
        document.getElementById("hd4").style.display = "block"
        document.getElementById("hd5").style.display = "block"
    } else if (selectValue === 'simpl') {
        document.getElementById("hd1").style.display = "block"
        document.getElementById("hd2").style.display = "block"
        document.getElementById("hd3").style.display = "block"
        document.getElementById("hd4").style.display = "block"
        document.getElementById("hd5").style.display = "block"
       
    } else if (selectValue === 'brett') {
        document.getElementById("hd1").style.display = "block"
        document.getElementById("hd2").style.display = "block"
        document.getElementById("hd3").style.display = "block"
        document.getElementById("hd4").style.display = "block"
        document.getElementById("hd5").style.display = "block"
       
    } else if (selectValue === "macha") {
        document.getElementById("hd1").style.display = "none"
        document.getElementById("hd2").style.display = "none"
        document.getElementById("hd3").style.display = "none"
        document.getElementById("hd4").style.display = "none"
        document.getElementById("hd5").style.display = "none"
    }
}

function chageLangSelect(){
    var langSelect = document.getElementById("selectbox");
    var selectValue = langSelect.options[langSelect.selectedIndex].value;
    type_num = selectValue;


    getFilterFunction()
    return selectValue;
}

function getFilterFunction() {
    var name = document.getElementById("method");
    var selectValue = name.options[name.selectedIndex].value;

    if (selectValue === 'hcirn') {
        lib = fBlind;
        fun_fiter = lib[type_num];
    } else if (selectValue === 'simpl') {
        lib = colorMatrixFilterFunctions;
        fun_fiter = lib[type_num];
    } else if (selectValue === 'brett') {
        lib = brettelFunctions;
        fun_fiter = lib[type_num];
    } else if (selectValue === "macha") {
        getMachadoMatrix(type_num, slide_value);
        fun_fiter = getMachado;
        
    } else {
        throw 'Invalid Filter Type!';
    }

    changemenu(selectValue)
}