//index.js

let express = require("express");
let app = express();
const path = require('path');
const helmet = require('helmet');

app.disable('x-powered-by');

const { expressCspHeader, INLINE, NONE, SELF } = require('express-csp-header');
app.use(expressCspHeader({
    directives: {
        'script-src': ['https://docs.opencv.org'],
    }
}));
app.use(express.static('public'));

app.listen(3000, function(){
    console.log("App is running on port 3000");
});

app.get("/", function(req, res){
    const filePath = path.join(__dirname, 'brettel_colorblind.html');
    res.sendFile(filePath);
});